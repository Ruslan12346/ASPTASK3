export const environment = {
  production: true,
  baseUrl: "https://webapplication120221016222122.azurewebsites.net/"
};
